package com.example.log_in_uygulamasi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
